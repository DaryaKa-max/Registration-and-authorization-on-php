<?php

$pdo = new PDO('mysql:dbname=register;host=localhost', 'root', 'root');