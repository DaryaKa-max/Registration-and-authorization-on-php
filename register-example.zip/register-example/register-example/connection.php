<?php
$host = 'localhost';    # адрес сервера 
$database = 'register'; # имя базы данных
$user = 'root';         # имя пользователя
$password = 'root';     # пароль
